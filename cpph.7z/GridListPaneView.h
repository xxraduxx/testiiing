#pragma once



// CGridListPaneView form view

class CTEtWorldGrid;
class CGridListPaneView : public CFormView
{
	DECLARE_DYNCREATE(CGridListPaneView)

protected:
	CGridListPaneView();           // protected constructor used by dynamic creation
	virtual ~CGridListPaneView();

public:
	enum { IDD = IDD_GRIDLISTPANEVIEW };
#ifdef _DEBUG
	virtual void AssertValid() const;
#ifndef _WIN32_WCE
	virtual void Dump(CDumpContext& dc) const;
#endif
#endif

protected:
	virtual void DoDataExchange(CDataExchange* pDX);    // DDX/DDV support

	DECLARE_MESSAGE_MAP()

protected:
	void SortColumn(int iCol, bool bAsc);

public:
	CXTListCtrl m_ListCtrl;
	bool m_bActivate;

	int m_nSortedCol;
	bool m_bAscending;
	CXTHeaderCtrl m_header;
	bool m_bSorting;


	afx_msg void OnSize(UINT nType, int cx, int cy);
	virtual void OnInitialUpdate();
	LRESULT OnRefresh( WPARAM wParam, LPARAM lParam );
	LRESULT OnSelectGrid( WPARAM wParam, LPARAM lParam );
	afx_msg BOOL OnEraseBkgnd(CDC* pDC);

	void AddGridList( CTEtWorldGrid *pGrid );
	afx_msg void OnLvnItemchangedList1(NMHDR *pNMHDR, LRESULT *pResult);
	afx_msg void OnHdnItemclickList1(NMHDR *pNMHDR, LRESULT *pResult);
};


